<template>
  <div class="dashboard">
    <h1>Dashboard</h1>
    <p>Bem-vindo ao painel administrativo!</p>
  </div>
</template>

<script setup>
// Aqui vai a lógica do componente (por enquanto vazio)
</script>

<style scoped>
.dashboard {
  padding: 20px;
}
</style>