<template>
  <div>
    <h1>Favoritos ({{ favorites.length }})</h1>

    <div v-if="loading">Carregando...</div>
    <div v-else-if="characters.length === 0">Nenhum favorito ainda.</div>

    <div class="grid">
      <CharacterCard v-for="c in characters" :key="c.id" :character="c" />
    </div>
  </div>
</template>

<script setup>
import { ref, watchEffect } from 'vue'
import { useFavoritesStore } from '@/store/favorites'
import api from '@/services/api_rickmorty'
import CharacterCard from '@/components/CharacterCard.vue'

const store = useFavoritesStore()
const favorites = store.favorites
const characters = ref([])
const loading = ref(false)

async function loadFavoritesCharacters() {
  if (favorites.length === 0) {
    characters.value = []
    return
  }
  loading.value = true
  try {
    // A API permite buscar múltiplos ids: /character/[1,2,3]
    const ids = favorites.join(',')
    const res = await api.get(`/character/${ids}`)
    // quando retorna 1 item, axios devolve objeto; normalizamos p/ array
    characters.value = Array.isArray(res.data) ? res.data : [res.data]
  } catch (err) {
    console.error(err)
    characters.value = []
  } finally {
    loading.value = false
  }
}

// carregar ao montar e quando favoritos mudarem
watchEffect(() => {
  loadFavoritesCharacters()
})
</script>

<style scoped>
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit,minmax(200px,1fr));
  gap: 1rem;
}
</style>
