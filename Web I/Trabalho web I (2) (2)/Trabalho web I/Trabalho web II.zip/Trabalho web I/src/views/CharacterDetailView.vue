<template>
  <div>
    <!-- VAZIO - você vai construir aqui -->
  </div>
</template>

<script>
export default {
  // VAZIO - você vai adicionar data(), mounted(), etc.
}
</script>

<style>
/* VAZIO - você vai adicionar CSS depois */
</style>