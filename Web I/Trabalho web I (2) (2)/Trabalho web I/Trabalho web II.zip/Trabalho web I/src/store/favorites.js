// src/store/favorites.js
import { defineStore } from 'pinia'

export const useFavoritesStore = defineStore('favorites', {
  state: () => ({
    favorites: [] // array de IDs (number)
  }),
  getters: {
    isFavorite: (state) => {
      return (id) => state.favorites.includes(Number(id))
    },
    favoritesCount: (state) => state.favorites.length
  },
  actions: {
    addFavorite(id) {
      id = Number(id)
      if (!this.favorites.includes(id)) {
        this.favorites.push(id)
      }
    },
    removeFavorite(id) {
      id = Number(id)
      this.favorites = this.favorites.filter(f => f !== id)
    },
    toggleFavorite(id) {
      id = Number(id)
      if (this.favorites.includes(id)) this.removeFavorite(id)
      else this.addFavorite(id)
    },
    setFavorites(arr) {
      this.favorites = arr.map(Number)
    }
  },
  // plugin de persistência cuidará do localStorage
  persist: {
    key: 'rm-favorites',
    storage: localStorage,
    paths: ['favorites']
  }
})


