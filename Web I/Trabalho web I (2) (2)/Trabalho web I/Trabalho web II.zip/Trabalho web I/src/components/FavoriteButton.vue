<template>
  <button @click="toggle" :aria-pressed="isFav" class="fav-btn">
    <span v-if="isFav">❤</span>
    <span v-else>♡</span>
  </button>
</template>

<script setup>
import { computed } from 'vue'
import { useFavoritesStore } from '@/store/favorites'

const props = defineProps({
  id: { type: [Number, String], required: true }
})

const store = useFavoritesStore()
const isFav = computed(() => store.isFavorite(props.id))

function toggle() {
  store.toggleFavorite(props.id)
}
</script>

<style scoped>
.fav-btn {
  border: none;
  background: transparent;
  font-size: 1.3rem;
  cursor: pointer;
}
</style>
