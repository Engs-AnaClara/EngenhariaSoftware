<template>
  <div class="card">
    <img :src="character.image" :alt="character.name" />
    <div class="info">
      <h3>{{ character.name }}</h3>
      <p>{{ character.status }}</p>
      <!-- botão de favoritar -->
      <FavoriteButton :id="character.id" />
    </div>
  </div>
</template>

<script setup>
import FavoriteButton from '@/components/FavoriteButton.vue'
const props = defineProps({
  character: { type: Object, required: true }
})
</script>
