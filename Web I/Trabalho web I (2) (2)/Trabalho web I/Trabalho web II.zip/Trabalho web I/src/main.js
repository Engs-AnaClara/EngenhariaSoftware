import { createApp } from 'vue';
import App from './App.vue';
import router from './router';
import pinia from './store';

import axios from 'axios';
import './services/api_rickmorty'; // Opcional: configura axios defaults aqui

const app = createApp(App);  // Aqui criamos a instância corretamente
app.use(router);
app.use(pinia);
app.mount('#app');
